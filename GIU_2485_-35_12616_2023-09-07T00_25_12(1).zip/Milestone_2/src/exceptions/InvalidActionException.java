package exceptions;

public class InvalidActionException extends GameActionException {

	public InvalidActionException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidActionException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
