package model.world;

public enum ResourceType {
	MANPOWER, GOLD
}
