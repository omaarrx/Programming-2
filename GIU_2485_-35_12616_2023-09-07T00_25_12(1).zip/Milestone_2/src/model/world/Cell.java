package model.world;

public abstract class Cell {

}
