package model.units;

public class Footman extends SupportUnit {

	public Footman() {
		super(200, 2, 1, 25);
	}

}
