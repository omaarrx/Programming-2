package model.units;

public enum HeroType {
	PACIFIST, AGGRESSOR

}
