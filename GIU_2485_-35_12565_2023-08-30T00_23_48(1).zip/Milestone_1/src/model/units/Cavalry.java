package model.units;

public class Cavalry extends SupportUnit {

	public Cavalry() {
		super(150, 3, 1, 30);
	}

}
