package model.units;

public class Archer extends SupportUnit {

	public Archer() {
		super(100, 2, 3, 35);
	}

}
