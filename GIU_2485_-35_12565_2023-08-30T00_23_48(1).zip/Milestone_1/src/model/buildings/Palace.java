package model.buildings;

public class Palace extends Building {

	public Palace() {
		super(1000);
	}

}
