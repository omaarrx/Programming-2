package model.buildings;

public class Tower extends Building {

	private boolean canAttack;
	private int range;

	public Tower() {
		super(200);
		this.range = 3;
		canAttack = true;
	}

	public boolean isCanAttack() {
		return canAttack;
	}

	public void setCanAttack(boolean canAttack) {
		this.canAttack = canAttack;
	}

	public int getRange() {
		return range;
	}

	public void setRange(int range) {
		this.range = range;
	}

}
