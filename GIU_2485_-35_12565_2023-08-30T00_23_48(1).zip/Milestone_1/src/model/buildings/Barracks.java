package model.buildings;

public class Barracks extends Building {

	private boolean canRecruit;

	public Barracks() {
		super(400);
		canRecruit = true;
	}

	public boolean isCanRecruit() {
		return canRecruit;
	}

	public void setCanRecruit(boolean canRecruit) {
		this.canRecruit = canRecruit;
	}

}
