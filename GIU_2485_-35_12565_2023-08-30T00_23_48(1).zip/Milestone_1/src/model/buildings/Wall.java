package model.buildings;

public class Wall extends Building{

	public Wall() {
		super(500);
	}

}
