package model.world;

public interface Upgradeable {

}
