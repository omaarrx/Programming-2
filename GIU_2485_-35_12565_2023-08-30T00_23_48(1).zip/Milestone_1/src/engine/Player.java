package engine;

import java.util.ArrayList;

import model.buildings.Building;
import model.units.Unit;

public class Player {

	private String name;
	private ArrayList<Unit> units;
	private ArrayList<Building> buildings;
	private int goldAmount;
	private int manpowerAmount;

	public Player(String name) {
		this.name = name;
		this.goldAmount = 700;
		this.manpowerAmount = 700;
		this.units = new ArrayList<Unit>();
		this.buildings = new ArrayList<Building>();

	}

	public int getGoldAmount() {
		return goldAmount;
	}

	public void setGoldAmount(int goldAmount) {
		this.goldAmount = goldAmount;
	}

	public int getManpowerAmount() {
		return manpowerAmount;
	}

	public void setManpowerAmount(int manpowerAmount) {
		this.manpowerAmount = manpowerAmount;
	}

	public String getName() {
		return name;
	}

	public ArrayList<Unit> getUnits() {
		return units;
	}

	public ArrayList<Building> getBuildings() {
		return buildings;
	}

}
