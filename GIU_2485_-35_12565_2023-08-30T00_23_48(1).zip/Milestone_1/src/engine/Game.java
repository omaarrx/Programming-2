package engine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import model.units.Assassin;
import model.units.Diplomat;
import model.units.Hero;
import model.units.Monk;
import model.units.Warchief;
import model.world.Cell;

public class Game {

	public Player player1;
	public Player player2;
	public Player currentPlayer;
	public Cell[][] map;
	public static ArrayList<Hero> availableHeroes;

	public Game(Player p1, Player p2) {
		this.player1 = p1;
		this.player2 = p2;
		this.currentPlayer = p1;
	}

	public static void loadHeroes(String filePath) throws IOException {
		availableHeroes = new ArrayList<>();
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		int i = 0;
		
		while (line != null) {
			String[] sp = line.split(",");
			Hero h;
			if (sp[1].equals("Diplomat")) {
				h = new Diplomat(sp[0], Integer.parseInt(sp[2]),
						Integer.parseInt(sp[3]), Integer.parseInt(sp[4]));
			} else if (sp[1].equals("Monk")) {
				h = new Monk(sp[0], Integer.parseInt(sp[2]),
						Integer.parseInt(sp[3]), Integer.parseInt(sp[4]));
			} else if (sp[1].equals("Warchief")) {
				h = new Warchief(sp[0], Integer.parseInt(sp[2]),
						Integer.parseInt(sp[3]), Integer.parseInt(sp[4]), Integer.parseInt(sp[5]));
			} else {
				h = new Assassin(sp[0], Integer.parseInt(sp[2]),
						Integer.parseInt(sp[3]), Integer.parseInt(sp[4]), Integer.parseInt(sp[5]));
			}
			availableHeroes.add(h);
			line = br.readLine();
		}
		br.close();
	}

}
